import template from "./insurance.html";
import controller from "./insurance.controller";
import "./insurance.scss";

let insuranceComponent = {
	bindings: {},
	template,
	controller
};

export default insuranceComponent;
