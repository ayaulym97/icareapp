import template from "./helperStatistics.html";
import controller from "./helperStatistics.controller";
import "./helperStatistics.scss";


let helperStatisticsComponent = {
	bindings: {},
	template,
	controller
};

export default helperStatisticsComponent;
