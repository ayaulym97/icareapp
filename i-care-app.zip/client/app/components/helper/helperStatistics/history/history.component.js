import template from "./history.html";
import controller from "./history.controller";
import "./history.scss";

let historyComponent = {
	bindings: {},
	template,
	controller
};

export default historyComponent;
