import template from "./helperStatisticsSidebar.html";
import controller from "./helperStatisticsSidebar.controller";
import "./helperStatisticsSidebar.scss";

let helperStatisticsSidebarComponent = {
	bindings: {},
	template,
	controller
};

export default helperStatisticsSidebarComponent;
