import template from "./statistics.html";
import controller from "./statistics.controller";
import "./statistics.scss";

let statisticsComponent = {
	bindings: {},
	template,
	controller
};

export default statisticsComponent;
