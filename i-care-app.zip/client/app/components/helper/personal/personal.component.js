import template from "./personal.html";
import controller from "./personal.controller";
import "./personal.scss";

let personalComponent = {
	bindings: {},
	template,
	controller
};

export default personalComponent;
