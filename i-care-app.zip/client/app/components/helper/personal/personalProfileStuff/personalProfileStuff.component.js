import template from "./personalProfileStuff.html";
import controller from "./personalProfileStuff.controller";
import "./personalProfileStuff.scss";

let personalProfileStuffComponent = {
	bindings: {},
	template,
	controller
};

export default personalProfileStuffComponent;
