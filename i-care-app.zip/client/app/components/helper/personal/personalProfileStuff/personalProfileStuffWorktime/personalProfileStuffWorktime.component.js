import template from "./personalProfileStuffWorktime.html";
import controller from "./personalProfileStuffWorktime.controller";
import "./personalProfileStuffWorktime.scss";

let personalProfileStuffWorktimeComponent = {
	bindings: {},
	template,
	controller
};

export default personalProfileStuffWorktimeComponent;
