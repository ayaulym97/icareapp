import template from "./personalProfileStuffRating.html";
import controller from "./personalProfileStuffRating.controller";
import "./personalProfileStuffRating.scss";

let personalProfileStuffRatingComponent = {
	bindings: {},
	template,
	controller
};

export default personalProfileStuffRatingComponent;
