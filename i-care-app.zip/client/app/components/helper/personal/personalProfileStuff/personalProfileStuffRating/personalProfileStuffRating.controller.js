class PersonalProfileStuffRatingController {
	constructor() {
		this.name = "personalProfileStuffRating";
	}
}

export default PersonalProfileStuffRatingController;
