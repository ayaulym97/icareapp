class PersonalProfileStuffProceduresController {
	constructor() {
		this.name = "personalProfileStuffProcedures";
	}
}

export default PersonalProfileStuffProceduresController;
