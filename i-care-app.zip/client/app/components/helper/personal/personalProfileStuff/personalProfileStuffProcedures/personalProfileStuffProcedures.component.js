import template from "./personalProfileStuffProcedures.html";
import controller from "./personalProfileStuffProcedures.controller";
import "./personalProfileStuffProcedures.scss";

let personalProfileStuffProceduresComponent = {
	bindings: {},
	template,
	controller
};

export default personalProfileStuffProceduresComponent;
