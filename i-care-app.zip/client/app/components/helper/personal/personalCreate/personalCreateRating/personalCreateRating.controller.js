class PersonalCreateRatingController {
	constructor() {
		// this.name = "personalCreateRating";
	}
}

export default PersonalCreateRatingController;
