import template from "./personalCreateRating.html";
import controller from "./personalCreateRating.controller";
import "./personalCreateRating.scss";

let personalCreateRatingComponent = {
	bindings: {},
	template,
	controller
};

export default personalCreateRatingComponent;
