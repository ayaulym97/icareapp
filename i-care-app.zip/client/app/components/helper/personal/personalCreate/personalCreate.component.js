import template from "./personalCreate.html";
import controller from "./personalCreate.controller";
import "./personalCreate.scss";

let personalCreateComponent = {
	bindings: {},
	template,
	controller
};

export default personalCreateComponent;
