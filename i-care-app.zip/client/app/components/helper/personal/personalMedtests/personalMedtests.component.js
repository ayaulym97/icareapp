import template from "./personalMedtests.html";
import controller from "./personalMedtests.controller";
import "./personalMedtests.scss";

let personalMedtestsComponent = {
	bindings: {},
	template,
	controller
};

export default personalMedtestsComponent;
