import template from "./personalStuff.html";
import controller from "./personalStuff.controller";
import "./personalStuff.scss";

let personalStuffComponent = {
	bindings: {},
	template,
	controller
};

export default personalStuffComponent;
