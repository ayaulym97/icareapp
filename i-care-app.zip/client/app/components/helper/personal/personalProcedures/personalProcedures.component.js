import template from "./personalProcedures.html";
import controller from "./personalProcedures.controller";
import "./personalProcedures.scss";

let personalProceduresComponent = {
	bindings: {},
	template,
	controller
};

export default personalProceduresComponent;
