import template from "./personalDoctors.html";
import controller from "./personalDoctors.controller";
import "./personalDoctors.scss";

let personalDoctorsComponent = {
	bindings: {},
	template,
	controller
};

export default personalDoctorsComponent;
