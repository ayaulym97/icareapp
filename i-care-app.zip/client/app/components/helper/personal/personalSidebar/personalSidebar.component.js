import template from "./personalSidebar.html";
import controller from "./personalSidebar.controller";
import "./personalSidebar.scss";

let personalSidebarComponent = {
	bindings: {},
	template,
	controller
};

export default personalSidebarComponent;
