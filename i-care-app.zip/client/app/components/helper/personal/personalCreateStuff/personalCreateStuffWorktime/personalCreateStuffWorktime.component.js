import template from "./personalCreateStuffWorktime.html";
import controller from "./personalCreateStuffWorktime.controller";
import "./personalCreateStuffWorktime.scss";

let personalCreateStuffWorktimeComponent = {
	bindings: {
		info:"="
	},
	template,
	controller
};

export default personalCreateStuffWorktimeComponent;
