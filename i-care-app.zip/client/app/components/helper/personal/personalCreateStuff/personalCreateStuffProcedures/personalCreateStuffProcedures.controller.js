class PersonalCreateStuffProceduresController {
	constructor() {
		this.name = "personalCreateStuffProcedures";
	}
}

export default PersonalCreateStuffProceduresController;
