import template from "./personalCreateStuffProcedures.html";
import controller from "./personalCreateStuffProcedures.controller";
import "./personalCreateStuffProcedures.scss";

let personalCreateStuffProceduresComponent = {
	bindings: {},
	template,
	controller
};

export default personalCreateStuffProceduresComponent;
