import template from "./personalCreateStuff.html";
import controller from "./personalCreateStuff.controller";
import "./personalCreateStuff.scss";

let personalCreateStuffComponent = {
	bindings: {},
	template,
	controller
};

export default personalCreateStuffComponent;
