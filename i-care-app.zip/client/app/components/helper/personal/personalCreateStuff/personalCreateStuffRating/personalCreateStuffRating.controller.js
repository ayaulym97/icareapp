class PersonalCreateStuffRatingController {
	constructor() {
		this.name = "personalCreateStuffRating";
	}
}

export default PersonalCreateStuffRatingController;
