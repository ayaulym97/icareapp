import template from "./personalCreateStuffRating.html";
import controller from "./personalCreateStuffRating.controller";
import "./personalCreateStuffRating.scss";

let personalCreateStuffRatingComponent = {
	bindings: {},
	template,
	controller
};

export default personalCreateStuffRatingComponent;
