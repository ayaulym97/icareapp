import template from "./personalCreateStuffMedtests.html";
import controller from "./personalCreateStuffMedtests.controller";
import "./personalCreateStuffMedtests.scss";

let personalCreateStuffMedtestsComponent = {
	bindings: {
		profileData: "="
	},
	template,
	controller
};

export default personalCreateStuffMedtestsComponent;
