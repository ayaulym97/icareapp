class PersonalController {
	constructor() {
		// this.name = "personal";
	}
}

export default PersonalController;
