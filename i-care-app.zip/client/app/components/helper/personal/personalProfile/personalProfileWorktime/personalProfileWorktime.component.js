import template from "./personalProfileWorktime.html";
import controller from "./personalProfileWorktime.controller";
import "./personalProfileWorktime.scss";

let personalProfileWorktimeComponent = {
	bindings: {},
	template,
	controller
};

export default personalProfileWorktimeComponent;
