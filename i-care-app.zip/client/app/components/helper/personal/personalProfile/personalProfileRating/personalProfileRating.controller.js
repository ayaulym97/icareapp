class PersonalProfileRatingController {
	constructor() {
		// this.name = "personalProfileRating";
	}
}

export default PersonalProfileRatingController;
