import template from "./personalProfileRating.html";
import controller from "./personalProfileRating.controller";
import "./personalProfileRating.scss";

let personalProfileRatingComponent = {
	bindings: {},
	template,
	controller
};

export default personalProfileRatingComponent;
