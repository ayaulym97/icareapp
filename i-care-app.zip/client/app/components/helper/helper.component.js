import template from "./helper.html";
import controller from "./helper.controller";
import "./helper.scss";

let helperComponent = {
	bindings: {},
	template,
	controller
};

export default helperComponent;
