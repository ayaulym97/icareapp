import template from "./calendar.html";
import controller from "./calendar.controller";
import "./calendar.scss";

let calendarComponent = {
	bindings: {},
	template,
	controller
};

export default calendarComponent;
