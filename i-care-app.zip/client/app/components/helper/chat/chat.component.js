import template from "./chat.html";
import controller from "./chat.controller";
import "./chat.scss";

let chatComponent = {
	bindings: {},
	template,
	controller
};

export default chatComponent;
