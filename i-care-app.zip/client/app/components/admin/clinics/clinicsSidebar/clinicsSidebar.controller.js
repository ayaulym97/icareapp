class ClinicsSidebarController {
	constructor(PreloadService, $rootScope, $timeout) {
		"ngInject";
		this.PreloadService = PreloadService;
		this.$rootScope = $rootScope;
		this.$timeout = $timeout;
	}


	//Selects clinic from sidebar
	selectClinic(clinic) {
		this.$rootScope.selectedClinic = clinic;
	}

	//Redirects to the EDIT modal window
	editClinic() {
		this.$timeout(() => this.$rootScope.$broadcast("modal:state", "editClinic"), 100);
	}

	//Redirects to the DELETE modal window
	deleteClinic() {
		this.$timeout(() => this.$rootScope.$broadcast("modal:state", "deleteClinic"), 100);
	}

	//Redirects to the CREATE CLINIC modal window
	appendClinic() {
		this.$timeout(() => this.$rootScope.$broadcast("modal:state", "appendClinic"), 100);
	}
}

export default ClinicsSidebarController;
