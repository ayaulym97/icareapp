class helperIndicatorsSidebarController {
	constructor(PreloadService, $rootScope, $timeout, $state) {
		"ngInject";
		this.PreloadService = PreloadService;
		this.$rootScope = $rootScope;
		this.$timeout = $timeout;
		this.$state = $state;
	}

	//Selects clinic from sidebar and go to the this clinic after click
	// selectClinicHelper(clinic) {
	// 	this.$state.go("admin.clinics");
	// 	this.$rootScope.selectedClinic = clinic;
	// }

	//Redirects to the EDIT modal window
	editClinic() {
		this.$timeout(() => this.$rootScope.$broadcast("modal:state", "editClinic"), 100);
	}

	//Redirects to the DELETE modal window
	deleteClinic() {
		this.$timeout(() => this.$rootScope.$broadcast("modal:state", "deleteClinic"), 100);
	}

	//Redirects to the CREATE CLINIC modal window
	appendClinic() {
		this.$timeout(() => this.$rootScope.$broadcast("modal:state", "appendClinic"), 100);
	}
}

export default helperIndicatorsSidebarController;
