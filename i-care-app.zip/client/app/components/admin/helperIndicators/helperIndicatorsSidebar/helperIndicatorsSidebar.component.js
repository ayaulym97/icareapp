import template from "./helperIndicatorsSidebar.html";
import controller from "./helperIndicatorsSidebar.controller";
import "./helperIndicatorsSidebar.scss";

let helperIndicatorsSidebarComponent = {
	bindings: {},
	template,
	controller
};

export default helperIndicatorsSidebarComponent;
