import template from "./adminStatistics.html";
import controller from "./adminStatistics.controller";
import "./adminStatistics.scss";

let adminStatisticsComponent = {
	bindings: {},
	template,
	controller
};

export default adminStatisticsComponent;
