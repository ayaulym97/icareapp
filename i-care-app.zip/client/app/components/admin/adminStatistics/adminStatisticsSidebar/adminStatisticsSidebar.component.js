import template from "./adminStatisticsSidebar.html";
import controller from "./adminStatisticsSidebar.controller";
import "./adminStatisticsSidebar.scss";

let adminStatisticsSidebarComponent = {
	bindings: {},
	template,
	controller
};

export default adminStatisticsSidebarComponent;
