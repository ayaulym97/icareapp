import template from "./admin.html";
import controller from "./admin.controller";
import "./admin.scss";

let adminComponent = {
	bindings: {},
	template,
	controller
};

export default adminComponent;
