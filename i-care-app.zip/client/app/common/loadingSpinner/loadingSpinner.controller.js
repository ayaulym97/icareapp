class LoadingSpinnerController {
	constructor() {
		// this.name = "loadingSpinner";
	}
}

export default LoadingSpinnerController;
