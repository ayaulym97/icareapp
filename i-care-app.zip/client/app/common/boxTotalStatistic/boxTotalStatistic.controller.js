class BoxTotalStatisticController {
	constructor() {
		// this.name = "boxTotalStatistic";
	}
}

export default BoxTotalStatisticController;
