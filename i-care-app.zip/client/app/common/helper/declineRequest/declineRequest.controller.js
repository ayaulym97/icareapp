import ApiConfig from "../../../utils/config";
import StaticTypes from "../../../utils/staticTypes";
import moment from "moment";
import _filter from "lodash/filter";

import Pikaday from "pikaday/pikaday.js";
import "pikaday/css/pikaday.css";


class DeclineRequestController {
	constructor($rootScope,CalendarService,$scope) {
		"ngInject";
		this.$rootScope = $rootScope ;
		this.CalendarService = CalendarService;
		this.$scope = $scope;
		this.ApiConfig = ApiConfig;
		this.moment = moment;
		this.requestTypes = StaticTypes.REQUEST_TYPES;

		this.btnState = false;
		this.stateReason = false;
		this.stateDropdown = false;

		this.currentReason={
		  id:0,
      text:"Выберите причину отказа",
      description:null
    };


    let field = window.document.getElementById("datepicker");
    let ctrl = this;
    let picker = new Pikaday({
      // Make a settings
      field: field,
      format: "DD MMMM",
      trigger: window.document.getElementById("datepicker-trigger"),
      minDate: moment().toDate(),
      firstDay: 1,
      keyboardInput: false,
      i18n: {
        previousMonth: "",
        nextMonth: "",
        months: ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"],
        weekdays: ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"],
        weekdaysShort: ["ВС", "ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ"]
      },
      onSelect: function (date) {
        ctrl.selectedDate = moment(date).format("YYYY-MM-DD");
        ctrl.dayOfWeek = moment(ctrl.selectedDate).weekday() + 1;
        ctrl.doctor.currentWorktime = _filter(ctrl.doctor.worktime, {day: ctrl.dayOfWeek});
      }
    })

		this.selectedTime = {
      start:"Время",
      end:null,
      value:null
    }

		this.reasonList =[
      {
        id:1,
        text:"Пациент не отвечает"
      },
      {
        id:2,
        text:"Отказ без объснений"
      },
      {
        id:3,
        text:"Поменять на другое время"
      },
      {
        id:3,
        text:"Другие причны отказа"
      },
    ]


  }
  showReasons(){
	  console.log(this);
    this.stateReason = !this.stateReason;
  }
  showWorktime(){
    this.stateDropdown = !this.stateDropdown;
  }

  selectReason(data){
    this.currentReason.text = data.text;
    this.currentReason.id = data.id;

  }

  selectTime(start,end , id){
   this.selectedTime.start = start;
   this.selectedTime.end = end;
		this.selectedTime.id = id;
  }

	//ON click the button "yes" delete request and close the modal
	deleteRequest(){
		this.btnState = !this.btnState;
		this.CalendarService.rejectRequest(this.worktime, this.doctor).then(()=>{
			this.$scope.$emit("request:decline:calendar",this.worktime,this.doctor);
		});
	}

	//Close the modal
	cancel(){
		this.$scope.$emit("modal:cancel");
	}
}

export default DeclineRequestController;
