import template from './requestState.html';
import controller from './requestState.controller';
import './requestState.scss';

let requestStateComponent = {
  bindings: {},
  template,
  controller
};

export default requestStateComponent;
