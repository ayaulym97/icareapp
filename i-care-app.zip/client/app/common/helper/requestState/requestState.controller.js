class RequestStateController {
  constructor() {
    this.name = 'requestState';
  }
}

export default RequestStateController;
