import angular from 'angular';
import uiRouter from 'angular-ui-router';
import requestStateComponent from './requestState.component';

let requestStateModule = angular.module('requestState', [
  uiRouter
])

.component('requestState', requestStateComponent)

.name;

export default requestStateModule;
