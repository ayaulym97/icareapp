import template from "./helperTopBar.html";
import controller from "./helperTopBar.controller";
import "./helperTopBar.scss";

let helperTopBarComponent = {
	bindings: {},
	template,
	controller
};

export default helperTopBarComponent;
