class BoxStatisticController {
	constructor() {
		// this.name = "boxStatistic";
	}
}

export default BoxStatisticController;
