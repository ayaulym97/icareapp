import template from "./appendHelperModal.html";
import controller from "./appendHelperModal.controller";
import "./appendHelperModal.scss";

let appendHelperModalComponent = {
	restrict: "E",
	bindings: {},
	template,
	controller
};

export default appendHelperModalComponent;
