class AdminTopBarController {
	constructor(AuthorizationService, $rootScope, $state, $window, PreloadService) {
		"ngInject";
		this.AuthorizationService = AuthorizationService;
		this.$rootScope = $rootScope;
		this.$state = $state;
    this.$window = $window;
		this.PreloadService = PreloadService;
	}

  //When click on button "Обновить" reload all app
  reloadProject() {
    this.$window.location.reload();
  }

	// For active class if current state is helper statistic or clinic list
	checkStateAdmin(){
		if (this.$state.current.name.includes("helperIndicators") || this.$state.current.name.includes("clinics")) {
			return true;
		} else {
			return false;
		}
	}

	//logout from system
	logout() {
		this.AuthorizationService.logout(true);
	}
}

export default AdminTopBarController;
