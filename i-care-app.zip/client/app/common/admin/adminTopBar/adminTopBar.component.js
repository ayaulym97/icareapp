import template from "./adminTopBar.html";
import controller from "./adminTopBar.controller";
import "./adminTopBar.scss";

let adminTopBarComponent = {
	bindings: {},
	template,
	controller
};

export default adminTopBarComponent;
