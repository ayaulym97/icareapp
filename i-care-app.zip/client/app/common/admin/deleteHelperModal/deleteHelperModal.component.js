import template from "./deleteHelperModal.html";
import controller from "./deleteHelperModal.controller";
import "./deleteHelperModal.scss";

let deleteHelperModalComponent = {
	restrict: "E",
	bindings: {},
	template,
	controller
};

export default deleteHelperModalComponent;
