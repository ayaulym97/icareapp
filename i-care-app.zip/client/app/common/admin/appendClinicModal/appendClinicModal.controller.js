import alertify from "alertifyjs/build/alertify.min";
import _forEach from "lodash/forEach";
import _map from"lodash/map";


class AppendClinicModalController {
	constructor(PreloadService, AuthorizationService, ClinicService, PlaceService, $scope, $timeout, $rootScope) {
		"ngInject";
		this.PreloadService = PreloadService;
		this.AuthorizationService = AuthorizationService;
		this.ClinicService = ClinicService;
		this.PlaceService = PlaceService;
		this.$scope = $scope;
		this.$timeout = $timeout;
		this.$rootScope = $rootScope;

		//do not allow open all two dropdowns
		this.stateDistrict = false;
		this.stateCity = false;

		//if user doesn't choose the District or City, the error will be shown
		this.invalidCity = false;
		this.invalidDistrict = false;
		this.invalidAddress = false;
		this.invalidName = false;
		this.invalidDescription = false;

		this.currentDistrict = {
			id: 0,
			name: "Выберите район"
		};
		this.currentCity = {
			id: 0,
			name: "Выберите город"
		};

		// The name of our clinic
		this.clinicName = null;

		//t The limit of helper counters
		this.helperCount = 1;
		this.minHelperCount = 1;
		this.maxHelperCount = 5;

		// ng-disabled variable, when button is submitted
		this.acceptClinic = false;

		this.data = {
			//If status of request is 0, we are creating online requests
			status: 0,
		};

		// Here will be the data of cities
		this.citiesList = [];

		this.SELECTED_COORDINATES = this.$rootScope.$on("geocoded:address", (event, data) => this.changeAddress(data));
		this.GEOCODED_COORDINATES = this.$rootScope.$on("geocoded:coordinates", (event, data) => this.changeCoordinates(data));
	}

	$onInit() {
	  //Generating cities list
    $(document).ready(function() {
      $(".pacient-phone").mask("+A(YYY)-YYY-YY-YY", {"translation": {
        A: {pattern: /[7,8]/},
        Y: {pattern: /[0-9]/}
      }
      });
    });
	  _forEach(this.PreloadService.cities, (city) => {
	    this.citiesList.push(city);
		});
	}

	$onDestroy() {
	  this.SELECTED_COORDINATES();
	  this.GEOCODED_COORDINATES();
  }

	//Check for typing address and setting it
	addressTyped() {
		if(this.currentDistrict.id === 0){
			this.$timeout(() => this.$rootScope.$broadcast("address:typed", `г.${this.currentCity.name}`), 750);
		}
		else {
			this.$timeout(() => this.$rootScope.$broadcast("address:typed", `г.${this.currentCity.name}, ${this.currentDistrict.name}, ${this.selectedAddress}`), 750);
		}
	}


	showCity() {
		this.stateCity = !this.stateCity;
		this.stateDistrict = false;
	}

	//Make dropdown of district visible
	showDistrict() {
		this.stateDistrict = !this.stateDistrict;
		this.stateCity = false;
	}

	//select city from dropdown
	selectCity(city) {
		this.data.city = city.id;
		this.data.districts = _map(city.district, (district) => district.id);
		this.currentCity = city;
		this.districtList = this.PreloadService.cities[this.currentCity.id-1].district;

		this.addressTyped();
	}

	//select district from district dropdown
	selectDistrict(district) {
		this.$timeout(() => this.stateDistrict = false, 0);
		this.currentDistrict = district;

		this.addressTyped();
	}

	// Change address text when clicked on yandex map
	changeAddress(data) {
		//We assign latitude and longitude
		this.selectedAddress = data.address;
		this.data.location_x = parseFloat(data.coordinates[0]);
		this.data.location_y = parseFloat(data.coordinates[1]);
	}

	// Return coordinates from map when we typed address in input
	changeCoordinates(data) {
		this.data.location_x = parseFloat(data[0]);
		this.data.location_y = parseFloat(data[1]);
	}

	//closes the modal
	cancel() {
		this.$rootScope.$broadcast("modal:cancel");
	}

	//Save and creating the clinic
	submit() {
		this.acceptClinic = true;

		//check for all inputs are filled
		if(this.currentCity.id === 0 || this.currentDistrict.id === 0 || this.selectedAddress === undefined || this.clinicName === undefined || this.clinicName === null ||this.clinicDescription === undefined || this.phone === undefined) {
			this.invalidCity = this.currentCity.id === 0;
			this.invalidDistrict = this.currentDistrict.id === 0;
			this.invalidAddress = this.selectedAddress === undefined;
			this.invalidClinicName = this.clinicName === undefined || this.clinicName === null;
			this.invalidDescription = this.clinicDescription === undefined;
			this.invalidNumber = this.phone === undefined;
			this.acceptClinic = false;
			return false;
		}

    this.invalidCity = false;
    this.invalidDistrict = false;
    this.invalidAddress = false;
    this.invalidClinicName = false;
    this.invalidDescription = false;
    this.invalidNumber = false;

		//
		// if(this.invalidAddress.length === 0){
		//   this.acceptClinic = false;
		//   this.invalidDistrict = true;
		//   console.log('DISTRICT');
		//   return false;
		// }
		//
		// if(this. === 0){
		//   this.acceptClinic = false;
		//   this.invalidDistrict = true;
		//   console.log('DISTRICT');
		//   return false;
		// }

    // Data which will send to server
		let data = {
			address: this.selectedAddress,
			name: this.clinicName,
			city: this.currentCity.id,
			district: this.currentDistrict.id,
			location_x: this.data.location_x,
			location_y: this.data.location_y,
      description: this.clinicDescription,
      phone: this.phone,
			type: 0,
		};

		let helperList = [];


		let saveAlert = alertify.notify("Добавление клиники...", "custom", 20);

		//Send data to server and creating it
		this.ClinicService.createClinic(data).then((response) => {
			saveAlert.delay(5).setContent("Клиника добавлена");
			console.log("[Admin] Clinic added");

      this.PlaceService.addPlacePhone({place: response.id, number: this.phone}).then((phoneRes) => {

        this.PreloadService.clinicsList.push(response);
        this.$rootScope.selectedClinic = response;
        if (this.helperCount >= 2) {
          for (let i = 0; i < this.helperCount; i++) {
            helperList.push({
              place: response.id,
              username: this.AuthorizationService.user.username + "-" + response.id + "-" + (i + 1),
              password: this.AuthorizationService.user.username + (i + 1),
              email: null,
              phone: null,
              type: 1
            });
          }
          helperList[0].type = 2;
        }
        else {
          helperList.push({
            place: response.id,
            username: this.AuthorizationService.user.username + "-" + response.id + "-" + 1,
            password: this.AuthorizationService.user.username + 1,
            email: null,
            phone: null,
            type: 2
          });
        }

        this.$timeout(() => this.$rootScope.$broadcast("modal:state", "appendHelper"), 0);
        this.$timeout(() => this.$rootScope.$broadcast("helper:append", {data: helperList, from: "appendClinic"}), 0);

      });

		}, () =>{
			this.acceptClinic = false;
			this.cancel();
			saveAlert.dismiss();
			alertify.error("Ошибка!");
		});
	}
}

export default AppendClinicModalController;
