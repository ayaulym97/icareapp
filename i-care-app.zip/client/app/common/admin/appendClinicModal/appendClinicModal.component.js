import template from "./appendClinicModal.html";
import controller from "./appendClinicModal.controller";
import "./appendClinicModal.scss";

let appendClinicModalComponent = {
	restrict: "E",
	bindings: {},
	template,
	controller
};

export default appendClinicModalComponent;
