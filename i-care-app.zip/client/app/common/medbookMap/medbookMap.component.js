import template from "./medbookMap.html";
import controller from "./medbookMap.controller";
import "./medbookMap.scss";

let medbookMapComponent = {
	bindings: {},
	template,
	controller
};

export default medbookMapComponent;
